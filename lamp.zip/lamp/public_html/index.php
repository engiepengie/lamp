<h1>Witaj</h1>
<h4>Próba połączenia z usługgą MySQL przez php...</h4>
<?php
$host = 'mysql';
$user = 'user';
$pass = 'root';
$conn = new mysqli($host, $user, $pass);

if ($conn->connect_error) {
die("Błąd połączenia: "  . $conn ->connect_error);
} else {
echo "Pomyślnie połączono z MySQL\n";
}
?>
